# Perform read operation on the designed table created in the above task.

select * from passenger;
select * from price;

# a. How many female passengers traveled a minimum distance of 600KMs?

-- count of female passengers
select  count(*) as female_passengers 
from passenger where gender = 'F' and distance >= 600;

/*INFERENCE:
		There are 2 female passengers traveled a minimum distance of 600kms */ 

-- details of female_passengers
select  * from passenger where gender = 'F' and distance >= 600;
		

/* b. Write a query to display the passenger details whose travel distance is greater than 
      500 and who are traveling in a sleeperbus. */
      
select * from passenger where distance > 500 and bus_type = 'Sleeper';


# c. Select passenger names whose names start with the character 'S'.

select passenger_name from passenger where Passenger_name like 'S%';

        
/*  d. Calculate the price charged for each passenger, displaying the Passengername, 
		BoardingCity, DestinationCity, Bustype, and Price in the output */
        
select pa.Passenger_name, pa.Boarding_City, pa.Destination_City, pa.Bus_type, pr.Price
from passenger pa
left join price pr on pa.bus_type = pr.bus_type and pa.distance = pr.distance;



# e. What are the passenger name(s) and the ticket price for those who traveled 1000KMs Sitting in a bus?

select pa.passenger_name, pr.price
from passenger pa left join price pr
on pa.bus_type = pr.bus_type and pa.distance = pr.distance 
where pa.bus_type = 'Sitting' and pa.distance = 1000;


/*INFERENCE:
		There are no passengers who traveled 1000kms sitting in a bus.
        This may be due to insufficiency of data. */ 
        
        
# f. What will be the Sitting and Sleeperbus charge for Pallavi to travel from Bangalore to Panaji?

select pa.Passenger_name, pr.Bus_Type, pr.price from passenger pa
join price pr on pa.bus_type = pr.bus_type and pa.distance = pr.distance
where pa.passenger_name = 'pallavi' and pa.boarding_city = 'bengaluru' AND pa.Destination_city = 'Panaji';

/*INFERENCE:
		There are no output for the requirement
        This is also due to insufficiency of data. */ 


# g. Alter the column category with the value "Non-AC" where the Bus_Type is sleeper
 
 update passenger set category = 'Non-AC' where bus_type = 'sleeper';
select * from passenger;
 

# h. Delete an entry from the table where the passengername is Piyush and commit this change in the database.
delete from passenger where passenger_name = 'piyush';
commit;


# i. Truncate the table passenger and comment on the number of rows in the table (explain if required)
Truncate table passenger;

/*The TRUNCATE TABLE statement removes all rows from the table, 
effectively deleting all data. It removes all the data from the table.
But the structure of the table still remains*/


# j. Delete the table passenger from the database.
drop table if exists passenger;